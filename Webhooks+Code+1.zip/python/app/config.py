class Config:
    DEVIN_API_URL = "https://api.devin.ai/v1/sessions"
    DEVIN_API_KEY = "apk_Y2xlcmstb3JnXzJocTJoWlhHaW9NQkM5R1JOZlNtNTg3TFZCdjo0MmMxMjQ5YjIzNzA0OTBjOWY5Zjk5N2RlM2ZmMGMwOA=="  # Replace with your Devin API key
    
    JIRA = {
       "domain": "rbtunes0.atlassian.net",
       "email": "rbtunes0@gmail.com",
       "api_token": "ATATT3xFfGF0zSNDcM4-GDWgaj0hDyBVIyqUIVfeSycD0HK5S6LxOm0H6wJjc3sSnhvZuRS-J9X_XyoCzaDnGT9bJNzPd49aRNSem9RBfsJDsAjhtZoUxKfXpm__i3gr3KdOfX_z-b6mkT8aVItfPzPvVcFQuflq3P9CIGk2PXi6_ORteWmQSwI=3538B3D8",
    }
    
    LINEAR = {
        "api_token": "lin_api_EkP3hvEkmekclpBsU0K8IyC2zLlzLD4LwGZOuh7G"
    }
    
    GITHUB = {
        "api_token": "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"
    }

    # Integration filters
    FILTERS = {
        "jira": {
            "trigger_mention": "@devin",
            "prompt_template": """
            User Prompt: {comment}
            Issue Summary: {issue_summary}
            Issue Description: {issue_description}
            """,
        },
        "linear": {
            "trigger_mention": "@devin",
            "prompt_template": """
            User Prompt: {comment}
            Issue Title: {issue_title}
            Issue Description: {issue_description}
            """,
        },
        "github": {
            "trigger_mention": "@devin-ai-integration",
            "prompt_template": """
            Issue URL: {url}
            User Prompt: {comment}
            Issue: {issue}
            """,
        },
    }